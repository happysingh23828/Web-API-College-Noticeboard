<?php
	
	define('DB_NAME','college_noticeboard');
	define('DB_USER','root');
	define('DB_PASSWORD','');
	define('DB_HOST', 'localhost');
	define('UPLOAD_PATH', 'localhost/images');


?>