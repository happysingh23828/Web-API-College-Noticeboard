<?php
	
	define('DB_NAME','rfgd_19825806_college_noticeboard');
	define('DB_USER','rfgd_19825806');
	define('DB_PASSWORD','sejal@123');
	define('DB_HOST', 'sql205.rf.gd');



?>